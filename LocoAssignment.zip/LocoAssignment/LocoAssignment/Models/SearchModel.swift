//
// SearchModel.swift
// Cityflo
//
// Created by Anshul Gupta on 16/08/24.
// Copyright © Cityflo. All rights reserved.
//


import Foundation

struct SearchModel: Codable {
    let movies: [Movie]?
    let totalResults: String?
    let response: String?
    
    enum CodingKeys: String, CodingKey {
        case movies = "Search"
        case totalResults
        case response = "Response"
    }
}


struct Movie: Codable {
    let title: String?
    let year: String?
    let imdbId: String?
    let type: String?
    let poster: String?
    let plot: String?
    let director: String?
    let releasedDate: String?
    
    enum CodingKeys: String, CodingKey {
        case title = "Title"
        case year = "Year"
        case imdbId = "imdbID"
        case type = "Type"
        case poster = "Poster"
        case plot = "Plot"
        case director = "Director"
        case releasedDate = "Released"
    }
}
