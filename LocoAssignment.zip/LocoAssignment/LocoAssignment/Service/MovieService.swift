//
// MovieService.swift
// Cityflo
//
// Created by Anshul Gupta on 19/08/24.
// Copyright © Cityflo. All rights reserved.
//

import Foundation
import Combine

class MovieService: MovieServiceProtocol, MovieDetailServiceProtocol {
   
    private let networkHelper: NetworkHelperProtocol
    
    init(networkHelper: NetworkHelperProtocol) {
        self.networkHelper = networkHelper
    }
    
    func searchMovies(by title: String, page: Int) -> AnyPublisher<SearchModel, NetworkError> {
        let encodedTitle = title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? title
        let parameters: [String: Any] = ["s": encodedTitle, "page": page]
        return networkHelper.fetch(endpoint: "", parameters: parameters)
    }
    
    func fetchMovieDetail(by id: String) -> AnyPublisher<Movie, NetworkError> {
        let parameters: [String: Any] = ["i": id]
        return networkHelper.fetch(endpoint: "", parameters: parameters)
    }
    
}
