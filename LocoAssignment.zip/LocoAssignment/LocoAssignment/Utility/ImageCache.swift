//
// ImageCache.swift
// Cityflo
//
// Created by Anshul Gupta on 19/08/24.
// Copyright © Cityflo. All rights reserved.
//

import Foundation
import Combine
import UIKit

protocol ImageLoaderProtocol {
    func loadImage(from urlString: String) -> AnyPublisher<UIImage?, Never>
    func clearCache()
}

class ImageLoader: ImageLoaderProtocol {
    static let shared = ImageLoader()
    private var imageCache = NSCache<NSString, UIImage>()
    private var cancellables = Set<AnyCancellable>()
    
    private init() {}
    
    func loadImage(from urlString: String) -> AnyPublisher<UIImage?, Never> {
        if let cachedImage = imageCache.object(forKey: urlString as NSString) {
            return Just(cachedImage).eraseToAnyPublisher()
        }
        
        guard let url = URL(string: urlString) else {
            return Just(nil).eraseToAnyPublisher()
        }
        
        return URLSession.shared.dataTaskPublisher(for: url)
            .map { UIImage(data: $0.data) }
            .handleEvents(receiveOutput: { [weak self] image in
                if let image = image {
                    self?.imageCache.setObject(image, forKey: urlString as NSString)
                }
            })
            .catch { _ in Just(nil) }
            .eraseToAnyPublisher()
    }
    
    func clearCache() {
        imageCache.removeAllObjects()
    }
}
