import Foundation
import UIKit
import Combine

protocol NetworkHelperProtocol {
    func fetch<T: Decodable>(endpoint: String, parameters: [String: Any]) -> AnyPublisher<T, NetworkError>
}

class NetworkHelper: NetworkHelperProtocol {
    
    static let shared = NetworkHelper()
    private let session: URLSession
    
    private init() {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForResource = 5
        session = URLSession(configuration: config)
    }
    
    func fetch<T: Decodable>(endpoint: String, parameters: [String: Any]) -> AnyPublisher<T, NetworkError> {
        guard let apiKey = Bundle.main.object(forInfoDictionaryKey: "Imdb_API_KEY") as? String else {
            return Fail(error: .other(NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "API Key not found in Info.plist"]))).eraseToAnyPublisher()
        }
        guard let urlString = Endpoint.urlWithQueryParameters(endpoint, parameters: parameters, apiKey: apiKey),
              let url = URL(string: urlString) else {
            return Fail(error: .invalidURL).eraseToAnyPublisher()
        }
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        
        return session.dataTaskPublisher(for: urlRequest)
            .tryMap { output in
                guard let httpResponse = output.response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                    throw NetworkError.noData
                }
                return output.data
            }
            .decode(type: T.self, decoder: JSONDecoder())
            .mapError { error in
                return error as? NetworkError ?? .other(error)
            }
            .eraseToAnyPublisher()
    }
}

extension NetworkHelper {
    struct Endpoint {
        static let base = "https://www.omdbapi.com/"
        
        static func urlWithQueryParameters(_ path: String, parameters: [String: Any], apiKey: String) -> String? {
            var components = URLComponents(string: base + path)
            var queryItems = [URLQueryItem(name: "apikey", value: apiKey)]
            
            for (key, value) in parameters {
                let stringValue: String
                
                if let value = value as? String {
                    stringValue = value
                } else if let value = value as? CustomStringConvertible {
                    stringValue = value.description
                } else {
                    continue
                }
                
                queryItems.append(URLQueryItem(name: key, value: stringValue))
            }
            
            components?.queryItems = queryItems
            return components?.url?.absoluteString
        }
    }
}

enum NetworkError: Error {
    case invalidURL
    case noData
    case decodingError
    case imageError
    case noInternetConnection
    case other(Error)
}
