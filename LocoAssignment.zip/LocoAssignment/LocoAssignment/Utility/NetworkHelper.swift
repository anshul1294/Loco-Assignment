import Foundation
import UIKit
import Combine

protocol NetworkHelperProtocol {
    func fetch<T: Decodable>(endpoint: String, parameters: [String: Any]) -> AnyPublisher<T, NetworkError>
}

class NetworkHelper: NetworkHelperProtocol {
    
    static let shared = NetworkHelper()
    private let session: URLSession
    private let apiKey = "3df3170a"
    
    private init() {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForResource = 5
        session = URLSession(configuration: config)
    }
    
    func fetch<T: Decodable>(endpoint: String, parameters: [String: Any]) -> AnyPublisher<T, NetworkError> {
        guard let urlString = Endpoint.urlWithQueryParameters(endpoint, parameters: parameters, apiKey: apiKey),
              let url = URL(string: urlString) else {
            return Fail(error: .invalidURL).eraseToAnyPublisher()
        }
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "GET"
        
        return session.dataTaskPublisher(for: urlRequest)
            .tryMap { output in
                guard let httpResponse = output.response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                    throw NetworkError.noData
                }
                return output.data
            }
            .decode(type: T.self, decoder: JSONDecoder())
            .mapError { error in
                return error as? NetworkError ?? .other(error)
            }
            .eraseToAnyPublisher()
    }
}

extension NetworkHelper {
    struct Endpoint {
        static let base = "https://www.omdbapi.com/"
        
        static func urlWithQueryParameters(_ path: String, parameters: [String: Any], apiKey: String) -> String? {
            var components = URLComponents(string: base + path)
            var queryItems = [URLQueryItem(name: "apikey", value: apiKey)]
            
            for (key, value) in parameters {
                let stringValue: String
                
                if let value = value as? String {
                    stringValue = value
                } else if let value = value as? CustomStringConvertible {
                    stringValue = value.description
                } else {
                    continue
                }
                
                queryItems.append(URLQueryItem(name: key, value: stringValue))
            }
            
            components?.queryItems = queryItems
            return components?.url?.absoluteString
        }
    }
}


enum NetworkError: Error {
    case invalidURL
    case noData
    case decodingError
    case imageError
    case noInternetConnection
    case other(Error)
}

//class NetworkHelper {
//    
//    static let shared = NetworkHelper()
//    private let session: URLSession
//    private let apiKey = "3df3170a" // My api key
//    
//    private init() {
//        let config = URLSessionConfiguration.default
//        config.timeoutIntervalForResource = 5
//        session = URLSession(configuration: config)
//    }
//    
//    struct Endpoint {
//        static let base = "https://www.omdbapi.com/"
//        
//        static func urlWithQueryParameters(_ path: String, parameters: [String: Any], apiKey: String) -> String? {
//            var components = URLComponents(string: base + path)
//            var queryItems = [URLQueryItem(name: "apikey", value: apiKey)]
//            
//            for (key, value) in parameters {
//                // Convert each value to a string representation
//                let stringValue: String
//                
//                if let value = value as? String {
//                    stringValue = value
//                } else if let value = value as? CustomStringConvertible {
//                    stringValue = value.description
//                } else {
//                    continue
//                }
//                
//                queryItems.append(URLQueryItem(name: key, value: stringValue))
//            }
//            
//            components?.queryItems = queryItems
//            return components?.url?.absoluteString
//        }
//    }
//   
//    func fetchMovieByID(_ imdbID: String) -> AnyPublisher<Movie, NetworkError> {
//        guard let endpoint = Endpoint.urlWithQueryParameters("", parameters: ["i": imdbID], apiKey: apiKey) else {
//            return Fail(error: .invalidURL).eraseToAnyPublisher()
//        }
//        return fetchFromNetwork(endpoint)
//    }
//    
//    func searchMovies(by title: String, page: Int) -> AnyPublisher<SearchModel, NetworkError> {
//        let encodedTitle = title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? title
//        guard let endpoint = Endpoint.urlWithQueryParameters("", parameters: ["s": encodedTitle,"page": page], apiKey: apiKey) else {
//            return Fail(error: .invalidURL).eraseToAnyPublisher()
//        }
//        return fetchFromNetwork(endpoint)
//    }
//    
//    private func fetchFromNetwork<T: Decodable>(_ endpoint: String) -> AnyPublisher<T, NetworkError> {
//        guard let url = URL(string: endpoint) else {
//            return Fail(error: .invalidURL).eraseToAnyPublisher()
//        }
//        
//        var urlRequest = URLRequest(url: url)
//        urlRequest.httpMethod = "GET"
//        
//        return session.dataTaskPublisher(for: urlRequest)
//            .tryMap { output in
//                guard let httpResponse = output.response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
//                    throw NetworkError.noData
//                }
//                return output.data
//            }
//            .decode(type: T.self, decoder: JSONDecoder())
//            .mapError { error in
//                return error as? NetworkError ?? .other(error)
//            }
//            .eraseToAnyPublisher()
//    }
//}
