//
// MovieCollectionViewCell.swift
// Cityflo
//
// Created by Anshul Gupta on 17/08/24.
// Copyright © Cityflo. All rights reserved.
//

import UIKit
import Combine

class MovieCollectionViewCell: UICollectionViewCell {
    
    // MARK: - UI Elements
    private lazy var posterImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 8
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        label.textAlignment = .center
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private var cancellables = Set<AnyCancellable>()
    
    
    // MARK: - Initializer
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(posterImageView)
        contentView.addSubview(titleLabel)
        setupConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Layout Constraints
    private func setupConstraints() {
        NSLayoutConstraint.activate([
            posterImageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            posterImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 4),
            posterImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -4),
            posterImageView.heightAnchor.constraint(equalTo: posterImageView.widthAnchor, multiplier: 1.5),
            titleLabel.topAnchor.constraint(equalTo: posterImageView.bottomAnchor, constant: 8),
            titleLabel.leadingAnchor.constraint(equalTo: posterImageView.leadingAnchor, constant: 4),
            titleLabel.trailingAnchor.constraint(equalTo: posterImageView.trailingAnchor, constant: -4),
            titleLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -8)
        ])
    }
    
    // MARK: - Configure Cell
    func configure(with movie: Movie, imageLoader: ImageLoaderProtocol) {
        titleLabel.text = movie.title
        if let urlString = movie.poster {
            imageLoader.loadImage(from: urlString)
                .receive(on: DispatchQueue.main)
                .sink { [weak self] image in
                    self?.posterImageView.image = image
                }
                .store(in: &cancellables)
        } else {
            posterImageView.image = UIImage(named: "placeholder")
        }
    }
}
