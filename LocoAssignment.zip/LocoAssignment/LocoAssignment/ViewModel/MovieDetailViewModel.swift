//
// MovieDetailViewModel.swift
// Cityflo
//
// Created by Anshul Gupta on 18/08/24.
// Copyright © Cityflo. All rights reserved.
//


import Foundation
import Combine
import UIKit

protocol MovieDetailServiceProtocol {
    func fetchMovieDetail(by id: String) -> AnyPublisher<Movie, NetworkError>
}

class DetailViewModel: ObservableObject {
    private let movieService: MovieService
    private let imageLoader: ImageLoader
    private let imdbId: String
    private var cancellables = Set<AnyCancellable>()
    
    @Published var movie: Movie?
    @Published var isLoading: Bool = false
    @Published var error: String?
    
    
    init(movieService: MovieService, imageLoader: ImageLoader, imdbId: String) {
        self.imdbId = imdbId
        self.movieService = movieService
        self.imageLoader = imageLoader
        self.fetchMovieDetails()
    }
    
    func fetchMovieDetails() {
        self.isLoading = true
        self.error = nil
        
        movieService.fetchMovieDetail(by: self.imdbId)
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { [weak self] completion in
                guard let self = self else { return }
                self.isLoading = false
                switch completion {
                case .finished:
                    break
                case .failure(let error):
                    self.error = error.localizedDescription
                }
            }, receiveValue: { [weak self] movieDetail in
                self?.movie = movieDetail
            })
            .store(in: &cancellables)
    }
    
    func loadImage(for url: String) -> AnyPublisher<UIImage?, Never> {
        return imageLoader.loadImage(from: url)
            .replaceError(with: nil)
            .eraseToAnyPublisher()
    }
}


