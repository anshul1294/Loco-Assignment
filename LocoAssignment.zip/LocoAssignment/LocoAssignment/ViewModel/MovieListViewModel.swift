//
// MovieListViewModel.swift
// Cityflo
//
// Created by Anshul Gupta on 17/08/24.
// Copyright © Cityflo. All rights reserved.
//

import Foundation
import Combine

protocol MovieServiceProtocol {
    func searchMovies(by title: String, page: Int) -> AnyPublisher<SearchModel, NetworkError>
}

class MovieListViewModel {
    
    // MARK: - Properties
    @Published private(set) var movies: [Movie] = []
    @Published private(set) var isLoading: Bool = false
    @Published private(set) var error: NetworkError?
    
    private var currentPage = 1
    private var totalResults = 0
    private var currentQuery: String = ""
    private let moviesPerPage = 20
    private var cancellables = Set<AnyCancellable>()
    
    private let movieService: MovieServiceProtocol
    
    // MARK: - Initialization
    init(movieService: MovieServiceProtocol) {
        self.movieService = movieService
    }
    
    // MARK: - Public Methods
    func fetchMovies(query: String? = nil) {
        if let query = query {
            currentQuery = query
            resetPagination()
        }
        
        guard !isLoading else { return }
        isLoading = true
        
        movieService.searchMovies(by: currentQuery, page: currentPage)
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { [weak self] completion in
                guard let self = self else { return }
                self.isLoading = false
                if case .failure(let error) = completion {
                    self.error = error
                }
            }, receiveValue: { [weak self] response in
                guard let self = self else { return }
                self.totalResults = Int(response.totalResults ?? "0") ?? 0
                self.movies.append(contentsOf: response.movies ?? [])
            })
            .store(in: &cancellables)
    }
    
    func loadMoreMoviesIfNeeded(currentItem item: Movie) {
        guard !isLoading, movies.count < totalResults, let lastItem = movies.last else { return }
        if item.imdbId == lastItem.imdbId {
            currentPage += 1
            fetchMovies()
        }
    }
    
    func resetPagination() {
        movies.removeAll()
        currentPage = 1
        totalResults = 0
    }
}
